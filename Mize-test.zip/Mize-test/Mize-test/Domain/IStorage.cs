﻿namespace Mize_test.Domain
{
    internal interface IStorage<T> where T : class
    {
        Task<T> Read();
        Task Write(T value);
    }
}