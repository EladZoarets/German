﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mize_test.Infrastructure;

namespace Mize_test.Domain
{
    internal class Storage<T>:IStorage<T> where T : class
    {
        #region Members
        private StorageSource<T> _storageSource;
        #endregion

        #region Properties
        public bool IsRead { get; }
        public bool IsWrite { get; }
        public TimeSpan ExpirationInterval { get; }
        public DateTime ExpartionTime { get; private set; }

        #endregion

        #region Contractors
        public Storage(bool isRead, bool isWrite, TimeSpan expirationInterval, StorageSource<T> storageSource)
        {
            IsRead = isRead;
            IsWrite = isWrite;
            ExpirationInterval = expirationInterval;
            ExpartionTime = DateTime.UtcNow.Add(expirationInterval);
            _storageSource = storageSource;

        }
        #endregion

        #region Methods
        public async Task<T> Read()
        {
            if (!IsRead)
                return null;

            if (DateTime.UtcNow > ExpartionTime)
                return null;

            return await _storageSource.Read();
        }

        public async Task Write(T value)
        {
            if (!IsWrite)
                return;

            ExpartionTime = DateTime.UtcNow.Add(ExpirationInterval);

            await _storageSource.Write(value);
        }
        #endregion


    }
}
