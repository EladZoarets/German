﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mize_test.Domain
{
    internal class ChainResource<T> where T : class
    {
        #region Members
        private readonly List<IStorage<T>> _storages;
        #endregion

        public async Task<T> GetValue()
        {
            T value = null;
            var i = 0;
            for(i=0; i < _storages.Count-1;i++) 
            {
                value = await _storages[i].Read();

                if (value != null)
                {
                    break;
                }
            }
            
            //Once a value is read from a Storage in the chain,
            //the value is propagated upwards and stored in each
            //Storage up the chain which supports writing
            for(var writeIndex = i-1; writeIndex > 0 ;writeIndex--) { }
            {
                await _storages[i].Write(value);
            }


            return value; 
        }
    }
}
