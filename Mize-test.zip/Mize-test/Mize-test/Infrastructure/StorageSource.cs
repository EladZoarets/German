﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Mize_test.Infrastructure
{
    internal interface StorageSource<T> where T:class
    {
        Task<T> Read();


        Task Write(T value);
        
    }

    internal class FileSource<T> : StorageSource<T> where T : class
    {
        private readonly string _filePath;
        public FileSource(string filePath) 
        { 
            if(string.IsNullOrWhiteSpace(filePath))
                throw new ArgumentNullException(nameof(filePath));

            _filePath = filePath;
        }
        public async Task<T> Read()
        {
            if (!File.Exists(_filePath))
            {
                return null;
            }

            var fileContent = await File.ReadAllTextAsync(_filePath);
            var fileValue = JsonSerializer.Deserialize<T>(fileContent);

            return fileValue;
        }

        public async Task Write(T value)
        {
            var jsonOptions = new JsonSerializerOptions { WriteIndented = true };
            var jsonValue = JsonSerializer.Serialize(value, jsonOptions);

            await File.WriteAllTextAsync(_filePath, jsonValue);
        }
    }

    internal class MemorySource<T> : StorageSource<T> where T : class
    {
        private T _value;
        public MemorySource(T value)
        {
            _value = value;
        }
        public async Task<T> Read()
        {
            return await Task.FromResult(_value);
        }

        public async Task Write(T value)
        {
            _value = value ?? throw new ArgumentNullException(nameof(value));
            await Task.CompletedTask;
        }
    }

    internal class WebServiceSource<T> : StorageSource<T> where T : class
    {
        private HttpClient _httpClient;
        private string _apiUrl;
        public WebServiceSource(string apiUrl)
        {
            _httpClient = new HttpClient();
            _apiUrl = apiUrl;
        }
        public async Task<T> Read()
        {
            var response = await _httpClient.GetAsync(_apiUrl);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var responseContent = await response.Content.ReadAsStringAsync();
           
            return JsonSerializer.Deserialize<T>(responseContent);
  
        }

        public async Task Write(T value)
        {
            throw new NotSupportedException("Write operation is not supported for WebServiceStorage.");
        }
    }
}
