﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("Please implement call here");
//Implement call here: i didn't do it but it suppose to be very easy